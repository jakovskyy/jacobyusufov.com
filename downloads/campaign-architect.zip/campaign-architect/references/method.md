# The Method

A behavior-change process in seven phases, adapted for marketing from published influence doctrine. The sequence is the point: each phase produces what the next one needs, and skipping one is how campaigns end up measuring the wrong thing or persuading the wrong people.

Contents

1. Phase I: Objectives
2. Phase II: Audience analysis (eight steps)
3. Phase III: Series design
4. Phase IV: Product design and pretesting
5. Phase V: Approval
6. Phase VI: Dissemination
7. Phase VII: Evaluation
8. Term glossary
9. Sources

---

## Phase I: Objectives

The objective is a countable behavior, never an attitude. The method does not care whether the audience likes the business. It cares whether they sign up, buy, renew, refer, show up, or switch. Everything else in the process exists to move that number.

**Campaign objective.** A verb-object statement of the overall change. "Increase renewals among first-year subscribers." "Decrease no-shows at scheduled consultations." It does not name the audience, because several audiences usually have to move for one behavior to change.

**Supporting objectives.** What one audience actually does. "The audience books a second appointment within thirty days." "The audience recommends the service in a professional group." Every campaign objective needs at least two supporting objectives. If you cannot write two, the campaign objective is too narrow.

**The three tests of a supporting objective.** The observer can count the number of times the behavior occurs. Other people know exactly what to look for when you describe it. The observer can see someone performing it when it happens.

**Strong verbs:** increases, decreases, buys, renews, books, registers, attends, refers, publicly recommends, switches, submits, completes, invites, returns.

**Weak verbs, rejected at planning:** believes, feels, likes, loves, hates, trusts, maintains, continues, refrains, stops, ceases, is aware of, engages with, considers.

**Baseline.** Collect it before launching anything. There is no way to show success if a starting point is not identified. A dashboard that starts on launch day can describe activity and can never prove causation.

---

## Phase II: Audience analysis

The single most important task in the process. The unit of analysis is one audience against one supporting objective. The output for each pairing is a worksheet that ends in a recommended argument and recommended actions.

### Step 1. Identify and refine the audience

Split every supporting objective into **primary actors** (the people who would perform the behavior) and **secondary actors** (the people who influence whether the primary actors do it: approvers, leaders, key communicators, family, peers, the person who signs the check). Then subdivide until you have specific organizations, tightly defined groups, named leaders, and named key communicators.

Four audience types, in order of preference:

1. **Organizations.** Shared purpose, shared information sources, a common interest. The best type, because one message reaches people who already talk to each other and act together.
2. **Demographic sets.** The most commonly used and the weakest, because members may share nothing but the label. The more specifically defined, the better. "Women 25 to 40" is a set. "Owners of independent gyms with under three hundred members in the metro area" is close to an organization.
3. **Leaders.** Low susceptibility and high payoff if moved. A leader who adopts the behavior brings the group.
4. **Key communicators.** Individuals the audience already trusts for information and interpretation. Use them as the voice. The message is more credible arriving through them than from the business.

Most marketing targets the demographic set because it is easy to buy media against. The method says that is the weakest choice available.

### Step 2. Determine effectiveness (0 to 5)

Effectiveness means: can this audience actually perform the behavior, and how much does it matter if they do. Three questions:

- What power, control, or authority does the audience have over the behavior?
- What restrictions bind them? Economic (they must give up income or spend money they control), legal, social (censure from their group), psychological (fear, habit), physical (access, distance).
- If they act, what share of the supporting objective does that account for? If most of the outcome sits with two groups, converting a third completely produces a small result.

A rating of 0, 1, or 2 means stop analyzing and pick another audience, or move the real decision-maker into the plan. An enthusiastic user who cannot buy without an approver is a low-effectiveness primary actor and a reason to make the approver the target.

### Step 3. Identify conditions (cause and effect)

All behavior serves a purpose and is the product of a continual cost-benefit calculation. The audience keeps doing what it does as long as the perceived benefits exceed the perceived costs. So before trying to change a behavior, write down the current behavior, its causes (external events and situations, internal attitudes and beliefs), and its effects (positive consequences, negative consequences, consequences for other groups).

Two laws govern the effects side. Reinforced behavior repeats. Short-term consequences outweigh long-term ones, and the more immediate the consequence, the more it controls the behavior.

Positive consequences fall into five buckets, and these are the real answer to "what purpose does the behavior serve":

- Escape or avoidance (of effort, risk, a decision, a conversation)
- Access to something tangible (money, time, a resource)
- Justice (fairness, getting even, being right)
- Power or control (over a process, a schedule, an outcome)
- Acceptance or affiliation (doing what the group does)

Every condition cites a source. Assumptions are labeled as assumptions.

Marketers analyze the desired behavior and skip the current one. The current behavior is the whole game because it is already being reinforced. If the audience keeps using the spreadsheet, ask what it gives them: avoidance of a new login, control over a process they understand, affiliation with how everyone in the office works. You do not beat a reinforced behavior with features. You beat it by lowering the perceived cost of switching, then raising the perceived cost of staying, in that order.

### Step 4. Identify vulnerabilities

The characteristics, motives, and conditions that can be used to influence the behavior. Four categories.

**Motives.** Primary (safety, security, physiological) and secondary (learned: money, status, recognition, control, belonging). Primary motives override everything. Prioritize as critical, short-term, and long-term.

**Psychographics.** Nine questions, used as an interview guide:

1. What does the audience fear?
2. What does it hate?
3. What angers it?
4. What does it love?
5. What does it consider shameful or embarrassing?
6. What is it dissatisfied with?
7. What are its norms, the things it does without question?
8. What does it value?
9. What frustrates it: what does it want that it cannot get?

Frustrations, shames, and hates are the richest sources of motive and the raw material for the argument.

**Demographics.** Only the ones that change the emotional or behavioral response to this specific behavior. A trait may govern one decision and be irrelevant to the next.

**Symbols.** Must be recognizable to the audience, carry meaning for the audience, and support the argument. Building recognition for a new symbol costs more than most campaigns have, so borrow symbols the audience already knows. Overused or sacred symbols annoy, and outsiders using them can offend.

### Step 5. Determine susceptibility (1 to 5)

The likelihood the audience is open to persuasion on this behavior, assessed on three factors: perceived risk of the desired behavior, perceived reward, and consistency with the audience's values and beliefs. Immediate risks and rewards outweigh distant ones. Behavior inconsistent with values decays over time, or the values get rewritten to fit the behavior.

The rating drives the plan.

- **Moderate to high susceptibility (3 to 5):** a series built mostly on messages.
- **Low susceptibility (1 to 2):** a series built mostly on actions, because conditions have to change before messaging can work. An action is a trial, a guarantee, a pricing change, a partnership, a public commitment, an integration, a product change: anything that removes the perceived risk or raises the perceived reward in the world rather than in the copy.

This is the most useful diagnostic in the method. If the audience rates low, more content will not fix it, and media spent against them is money dropped on people who have decided not to read.

### Step 6. Determine accessibility

For each medium, individually:

- How the audience currently receives information through it.
- Reach (people exposed at least once per period) and frequency (exposures per person per period). Count people, not subscriptions, devices, or impressions.
- Whether the audience uses the medium for entertainment or for information. Entertainment audiences will not sit through a serious message.
- Whether use is active (sought out) or passive (encountered).
- Whether the audience consumes it alone or with others. Group consumption invites discussion, and audiences that discuss an argument are more likely to be persuaded by it.
- Whether a new medium would help through novelty or distract from the message.

Each medium gets a 1 to 5 rating with stated pros and cons. Prefer channels where the audience talks to each other about what they saw.

### Step 7. Build the argument

The argument is the framework the series is built on. It contains no product wording. Four parts: the main argument is the foundation, supporting arguments are the walls, the appeal and techniques are the roof.

**Main argument.** One or two sentences: the conclusion the audience must reach in order to act. Format: *Doing X (the desired behavior) will result in Y (the outcome the audience wants).* Built by linking the desired behavior to one or more vulnerabilities.

**Supporting arguments.** Facts, specific examples, and consequences from the cause-and-effect analysis. Each gives the audience one more reason to accept the main argument. Not every vulnerability becomes a supporting argument. Some are better addressed by actions. Supporting arguments are sequenced, and sequence matters (see Phase III).

**Appeal.** The tone the argument is presented in, chosen from conditions and vulnerabilities. See `appeals-and-techniques.md`.

**Techniques.** The specific presentation methods. See `appeals-and-techniques.md`.

Write the main argument before any headline. It is the sentence every product in the series has to serve.

### Step 8. Refine assessment criteria

Assessment criteria are written as questions that, answered over time, describe a behavior trend: "How many members of the audience booked a second appointment within thirty days in the period?" They must be specific, measurable, and observable, with setting, frequency, rate, place, and time. If the supporting objective increases a behavior, measure the desired behavior. If it decreases one, measure the current behavior.

---

## Phase III: Series design

Only on rare occasions does a single product change the behavior of an audience. A series is every product and action built for one supporting objective and one audience, across a deliberate mix of media, so the audience meets the same argument several times in different forms.

**Staging.** Supporting arguments are staged. Stage one products carry supporting argument one. Stage two carries supporting argument two. Stage two is not released until posttesting shows the audience has accepted stage one. Those gates are decision points on the calendar. Some supporting arguments stand alone, some are mutually supporting, some cannot be introduced until the prior one is accepted. Nobody checks whether the audience accepted "we have the data" before shipping "and it costs less than what you use now." The gate is the part marketing skips.

**Actions as products.** An action taken for its effect on the audience is planned on the same worksheet as the ad. A free audit, an in-person training, a sponsored class, a pilot with one organization, a public guarantee, a pricing move. Actions exist to legitimize a supporting argument: the free trial exists so the audience believes "switching costs you nothing."

**Series worksheet.** Fixes the main and supporting arguments, the appeal, the techniques, the symbols repeated across every product, and the count of products per medium. The dissemination plan fixes, for every product: duration, timing, frequency, location, placement, quantity.

**Naming.** Every asset carries a name that encodes campaign, objective, audience, medium, stage, and sequence, so any piece traces back to the behavior it serves. Most content libraries cannot answer "which objective does this asset serve," and this convention is the fix.

**Saturation.** Do not oversaturate. Flooding a small audience with one message teaches them to stop reading any message, and the damage lands on your own channel. Ensure enough coverage to move the behavior and no more.

---

## Phase IV: Product design and pretesting

### Product design rules that hold up

- Format familiarity beats novelty. Unfamiliar formats cost credibility.
- Headline matches content. Subheadline is the bridge. Captions in present tense. Illustrations tied to the text.
- Eye direction: suggestive direction (tone, posture, gaze) is best because the reader does not notice it. Mechanical direction (arrows, lines) is weakest because the reader notices and may resent being steered.
- Color is the first thing seen and its meaning is cultural. Check it per audience.
- Quality of physical items is a credibility issue. A branded object that breaks damages you as much as an offensive message.
- Audio depends on repetition and a fixed schedule so listening becomes a habit. The voice's emotional tone may matter more than the logic. Audio is fleeting and needs reinforcement from durable media.
- Carrying a story against your own interest buys trust that cannot be bought any other way. A publication that only prints good news about the business loses the credibility that made it worth reading.
- The winning product is often the humblest one, and it is found by posttesting, not by taste. In one documented program, a wallet-sized card outperformed billboards, posters, radio, and television because people could carry it privately.
- Writing: eliminate the writer's own views and assumptions, use current idiom, put people who know the audience in the room.

### Pretesting

Pretesting answers two questions before anything ships: is the message clearly understood by the audience, and is the audience likely to perform the behavior because of the argument. Not "do they like it."

**Methods.** Survey samples (random, stratified, or cluster, since accidental and quota samples are weaker) and test groups (a panel of experts, a panel of representatives, actual audience members). Use as many as time allows.

**Test for understanding** with open-ended questions: What does this tell you to do? What does this say? What does this mean to you?

**Test for acceptance** by asking about peers, not the respondent: After seeing this, do you think owners like you would do X? Why or why not? What would be the main reason they would? Asking about peers relieves the pressure to answer politely and lets the respondent project their own view safely. The worked case in the source material found two motivators the product had missed and rewrote the argument around them.

**Report counts, not percentages.** "Eight of ten understood the product," never "80 percent," because the sample is almost never large or random enough for a percentage to mean anything.

**Test three variants** with different appeals and ask which is most persuasive. Look for recurring comments.

**Classify deficiencies** as understanding, acceptance, or exposure.

**Four kinds of fix:** change the product, change the argument, change the dissemination, or split the audience. Split the audience whenever results diverge along a line you had not drawn. That is a new audience, not a noisy sample.

**The cautionary case.** A product approved without pretesting to hit a leadership deadline was read by one segment of the audience as a threat from another segment. The run was cancelled the morning after, when the test finally happened. The lesson is not "be careful." It is that skipping the test to hit the date produces the opposite of the intended effect.

---

## Phase V: Approval

A program approval carries: objectives, audiences, themes to stress and themes to avoid, means of dissemination, attribution, concept of operations, concept of assessment with feedback mechanisms, exposure to unintended audiences, risk rating, and public relations guidance. That structure is a campaign brief.

**Approval philosophy.** Plan centrally, execute at the edge, delegate approval to the lowest practical level, review simultaneously rather than serially, and set a fixed hour after which silence is consent. Reviewers comment. They do not veto. The series never goes back to the writers for changes until the final decision. One named approver.

**Themes to avoid,** which double as brand guardrails: ultimatums you have no intent or capability to enforce, anything that favors one group at the perceived expense of another, anything that legitimizes breaking the law, anything that implies your own moral, cultural, or ideological superiority, and anything that reads as taking sides in a political or religious contest, because it splits audiences that were previously receptive to you as a whole.

**Credibility.** If you tell the audience something is true and it is not, they will prove it in public and your credibility with every audience is gone. Even unbranded activity is bound by the rule that any information ultimately disclosed cannot be deceptive.

---

## Phase VI: Dissemination

Factors: constraints on the business, physical conditions, a competitor's ability to disrupt, the audience's comprehension of the medium, infrastructure, and the credibility of each medium with this audience. Multiple means are always preferred.

**Face-to-face** is one of the most powerful means available. Advantages: audience selection, immediate feedback, credibility (the audience can evaluate the source), the ability to present complex material and repeat with variation, low cost. Disadvantages: limited range, and the control problem, where a message passed person to person degrades, so it must be reinforced by other media.

**The encounter outline,** which is a sales call plan:

1. Introduction and rapport, including the formalities this audience expects.
2. Presentation of the main and supporting arguments as specific points with facts.
3. Predicted questions and objections, each with a prepared response.
4. An exit that leaves a deliverable and extracts a commitment if it went well, or exits without escalation and documents why if it went poorly.

Mirror the audience, subtly. Regular, scheduled locations turn dissemination into a habit the audience returns to. Face-to-face plus reinforcing media is the answer to the sales-versus-marketing split: the person carries the argument, the media keep it from degrading between visits.

---

## Phase VII: Evaluation

Four inputs: assessment criteria (the questions), impact indicators (the answers over time), spontaneous events (anything outside your control that moved the behavior, positive or negative), and posttest results (exposure, understanding, acceptance, and stated position).

Baseline data is collected before the series runs. Indicators are collected at regular intervals before, during, and after. The assessment matrix lays the indicators, the spontaneous events, and external influences against the series timeline so the correlation can be read. The campaign is only one of many influences, and the job is to explain the trend, not claim it.

**Keep a spontaneous events log** next to the metrics: the price change, the competitor's launch, the news story, the outage, the season. Without it, every dip and spike gets attributed to the campaign.

**Evaluation report format.** Campaign objective, supporting objective, audience, series name, period, a bottom-line summary first, series description, assessment criteria, impact indicators with baseline and change, spontaneous events with dates, posttest counts for exposure, understanding, and acceptance, and a conclusion with a recommendation.

**Reallocate** to the product that posttests best, even when it is the humblest one.

**The reference case.** Baseline: one or two calls per day to a tip line. Series: billboards, posters, wallet cards, radio and television spots, and news coverage of the results, with anonymity as the central supporting argument. Result: six to eight calls per day within months, spikes after major events, decline when a competing line launched. Defaced posters were read as evidence of effect. Wallet cards won on posttesting and the print run went from four hundred thousand to over a million. Every element of evaluation is in that paragraph: baseline, indicator, spontaneous events, posttest-driven reallocation.

---

## Term glossary

| Term in this skill | Meaning |
|---|---|
| Campaign objective | Verb-object statement of the overall behavior change |
| Supporting objective | One audience's countable, observable behavior |
| Primary actors | The people who perform the behavior |
| Secondary actors | The people who influence whether the primary actors perform it |
| Key communicator | A person the audience already trusts for information |
| Conditions | Causes and effects of the current behavior |
| Vulnerabilities | Motives, psychographics, demographics, and symbols usable for influence |
| Effectiveness | Whether the audience can perform the behavior and how much it matters (0 to 5) |
| Susceptibility | Openness to persuasion: risk, reward, value consistency (1 to 5) |
| Accessibility | Which media reach the audience and how they use them (1 to 5 per medium) |
| Argument | Main argument, supporting arguments, appeal, techniques |
| Action | Something done in the world to make a supporting argument credible, planned as a product |
| Series | All products and actions for one supporting objective and one audience |
| Stage / gate | Supporting arguments released in order, each gated by posttest |
| Pretest / posttest | Understanding and acceptance before. Exposure, understanding, and acceptance after |
| Assessment criteria | Questions whose answers over time show a behavior trend |
| Impact indicators | The answers: counted behaviors |
| Spontaneous events | Uncontrolled events that moved the behavior |
| Themes to stress / avoid | Brand pillars and brand guardrails |

---

## Sources

Adapted from published United States government doctrine on influence operations: *Military Information Support Operations Process* (ST 33-01, 2014) and the *MISO Supplement to the Joint Strategic Capabilities Plan* (CJCSI 3110.05F, 2017). Both are public documents. The translation to marketing, the floor, the worksheets, and the sequencing rules in this skill are original to the author.
