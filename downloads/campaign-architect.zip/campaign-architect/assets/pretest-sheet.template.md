# Pretest Sheet: [asset name]

Panel: [experts / representatives / audience members], [count].
Variants tested: A [appeal], B [appeal], C [appeal].

## Understanding (open-ended, per respondent)

What does this tell you to do?
What does this say?
What does this mean to you?

## Acceptance (asked about peers, per respondent)

After seeing this, would [people like you] do [behavior]? Why or why not?
What would be the main reason they would?
Which of the three is most persuasive, and why?

## Tally (counts, never percentages)

| | Understood the action | Would act (peers) | Chose as most persuasive |
|---|---|---|---|
| A | of | of | of |
| B | of | of | of |
| C | of | of | of |

Recurring comments: [ ]
Deficiency type: [understanding / acceptance / exposure]
Fix: [change the product / change the argument / change the dissemination / split the audience]
Results diverged along a line not drawn? [yes: new audience is ___ / no]
