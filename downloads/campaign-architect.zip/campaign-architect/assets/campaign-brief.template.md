# Campaign Brief: [campaign name]

Prepared [date]. Approver: [name]. Review hour: [time]. Depth: [full / short].

## 1. Objective

Campaign objective: [verb-object statement]

Supporting objectives (each a countable behavior one audience performs):
- A. The [audience] [verb] [object]. Baseline: [count, period, source].
- B. The [audience] [verb] [object]. Baseline: [count, period, source].

## 2. Audiences

For each supporting objective: primary actors, secondary actors, key communicators, refined to organizations where possible. (One audience worksheet per audience.)

## 3. Effectiveness (0 to 5 per audience)

[audience]: [rating]. Control: [ ]. Restrictions: [ ]. Share of the objective: [ ].

## 4. Current behavior

What the audience does today: [ ]. Causes: [ ]. What it gives them, by bucket (escape or avoidance, access, justice, control, affiliation): [ ]. Negative consequences they name: [ ]. Source for each: [ ].

## 5. Vulnerabilities

Motives: [ ]. The nine questions (fear, hate, anger, love, shame, dissatisfaction, norm, value, frustration): [ ]. Demographics that change the response: [ ]. Symbols the audience already recognizes: [ ].

## 6. Susceptibility (1 to 5 per audience)

[audience]: [rating]. Perceived risk: [ ]. Perceived reward: [ ]. Value consistency: [ ]. Therefore this series is built mostly on [messages / actions].

## 7. Accessibility (1 to 5 per medium)

| Medium | Reach in people | Information or entertainment | Alone or group | Rating |
|---|---|---|---|---|

## 8. The argument

Main argument: Doing [X] will result in [Y].
Supporting arguments, in sequence: 1. [ ] 2. [ ] 3. [ ]
Appeal: [from the allowed list]. Techniques: [ ].
The other side, published: [the strongest honest case against the behavior].

## 9. The series

Stage one: products and actions [ ]. Gate to stage two: [posttest condition].
Stage two: [ ]. Gate: [ ].
Stage three: [ ].
Asset naming: [campaign]-[objective]-[audience]-[medium]-[stage]-[sequence].

## 10. Pretest plan

Who: [panel]. Questions for understanding: what does this tell you to do, what does it say, what does it mean to you. Question for acceptance, asked about peers: [ ]. Variants: three, with different appeals. Report: counts.

## 11. Approval

Approver: [ ]. Reviewers, simultaneous: [ ]. Silence is consent at: [ ].

## 12. Assessment

Criteria, as questions: [ ].
Baseline: [ ]. Indicators and interval: [ ].
Spontaneous events log: [what to watch].
Posttest plan: [who, when, counts].
Report cadence: [ ].
