# License

Copyright (c) 2026 [Licensor name]. All rights reserved.

This is a draft commercial license for review by the licensor's counsel before publication. It is not legal advice.

## Grant

On purchase, the licensor grants the purchaser a non-exclusive, non-transferable, perpetual license to install and use this skill (the SKILL.md file, the reference files, and the templates) within one organization, for any number of users and projects inside that organization, on any AI agent or tool that reads the skill format.

## Permitted

- Filling in and modifying the templates for the purchaser's own use.
- Editing the house-rules file and the skill's instructions to fit the purchaser's business.
- Producing campaign briefs, worksheets, and reports with the skill and using them for any purpose, including client work by an agency or consultant.

## Not permitted

- Redistributing, reselling, sublicensing, or publishing the skill or any of its files, in whole or in part, modified or unmodified.
- Removing this license or the attribution in the reference files.
- Making the skill available to a second organization. A consultant or agency serving multiple clients may use the skill on their behalf and may not install it on the client's systems.

## Sources

The method adapts published, public United States government doctrine. The translation to marketing, the floor, the worksheets, the worked example, and the sequencing rules are original work of the licensor and are covered by this license.

## Warranty

The skill is provided as is. The licensor makes no warranty about the results of any campaign planned with it.

## Updates

Purchasers receive updates to version 1.x at no charge through the channel of purchase.
