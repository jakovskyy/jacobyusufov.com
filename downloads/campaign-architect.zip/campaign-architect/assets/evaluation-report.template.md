# Evaluation Report: [series name]

Campaign objective: [ ]. Supporting objective: [ ]. Audience: [ ]. Period: [ ].

## Bottom line

[Two sentences: did the behavior move, and what is recommended.]

## Series description

[Products and actions that ran, by stage, with dates.]

## Assessment criteria

[The questions.]

## Impact indicators

| Indicator | Baseline | This period | Change |
|---|---|---|---|

## Spontaneous events

| Date | Event | Likely effect on the behavior |
|---|---|---|

## Posttest counts

Exposure: [ ] of [ ] saw it. Understanding: [ ] of [ ] stated the action correctly. Acceptance: [ ] of [ ] said peers would act. Stated position: [ ].

## Conclusion and recommendation

[Explain the trend, name the influences, and say what changes: product, argument, dissemination, audience, or budget reallocation to the product that posttested best.]
