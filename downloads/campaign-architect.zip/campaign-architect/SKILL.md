---
name: campaign-architect
description: Builds a campaign brief the way influence professionals do it. Objectives written as countable behaviors, primary and secondary actors for each one, analysis of what the audience does today and why, a susceptibility score that decides whether to spend on media or change the offer, a staged series with go/no-go gates, a pretest plan, and evaluation against a baseline. Use whenever the user plans, builds, or reviews a campaign, ad, commercial, launch, go-to-market plan, positioning, messaging strategy, content push, or marketing strategy for any product, service, cause, or candidate, including when they call it "a plan," "some ideas," "a push," or "how do we get people to." Also use to audit an existing marketing plan, brief, or ad against the method.
---

# Campaign Architect

## What this does

Most marketing plans fail at the first line. They set out to raise awareness, build affinity, or drive engagement, and none of those can be counted, so nothing that follows can be tested. This skill runs a campaign the way behavior-change professionals run one: the objective is a behavior the audience performs, the plan names who performs it and who influences them, the analysis starts with what the audience does today instead, and every piece of the campaign traces back to the behavior it serves.

The method has seven phases: objectives, audience analysis, series design, product design and pretesting, approval, dissemination, and evaluation. `references/method.md` carries the full method. This file tells you how to run it.

## Before you start: find the house rules

The method is generic. What makes the output sound like this business and stay inside its limits is a house-rules file. Look for `house-rules.md` in the working directory, in `.claude/`, or wherever the user points you. Read it before writing anything.

If there is no house-rules file, run the intake. Ask the user, in one message, for the ten things in `assets/house-rules.template.md`: the business and what it sells, who buys and who influences the buyer, the current channels, banned and preferred words, the allowed appeals, the tone, the named approver and review hour, the depth setting, and any claim they will never make. Write `house-rules.md` from their answers and confirm it before proceeding. The file is reused on every campaign after that, so the intake happens once.

## The floor

These limits hold for every user and every configuration. They exist because the method descends from influence doctrine, and the doctrine's own record shows what happens when they are crossed: one false claim the audience can check destroys credibility with every audience at once.

- No deception. Every claim survives being checked by the audience, a competitor, or a journalist.
- No false attribution. The source of a message is either the business or a disclosed partner. Nothing is placed in a competitor's or a customer's voice without their agreement.
- No fear framing, aversive stimulation, or manufactured urgency. Persuasion goes to lowering the cost of the behavior, never to pressuring the decision.
- No in-group versus out-group appeals. Dividing an audience against another group splits audiences that were receptive to the business as a whole.
- No claim the audience can refute with a screenshot. The refutation travels further than the claim.
- Publish the strongest argument against the behavior at the same weight as the argument for it, when the audience cannot verify your value claim but can verify whether you said the inconvenient thing.

A house-rules file can add limits. It cannot remove these.

## Two modes

**Brief mode** is the default. When the user wants to plan, build, or think through a campaign, produce the full brief in the shape below.

**Checklist mode** runs when the user pastes an existing plan, brief, ad, or deck, or asks whether something holds up. Interrogate it with the checklist at the end of this file and report only what fails, with the fix. Write nothing new unless asked.

If you cannot tell which mode the user wants, ask in one line.

## The brief

Write it in prose, in complete sentences, in the tone the house rules specify. Cite a source for every stated condition and label every assumption as an assumption. Report counts as counts, never as percentages, because samples in marketing are almost never large enough for a percentage to mean anything. Use `assets/campaign-brief.template.md` for the structure and `assets/audience-worksheet.template.md` for each audience.

**1. Objective.** One campaign objective as a verb-object statement, then at least two supporting objectives, each a behavior a specific audience performs. Test each supporting objective with three questions: can an observer count how many times it occurs, would someone else know exactly what to look for, and can it be seen happening. Reject believes, feels, likes, maintains, refrains, and every form of awareness or engagement. For each behavior, state the baseline. If there is no baseline, collecting one is the first task in the plan, because a campaign that starts measuring on launch day can never prove it moved anything.

**2. Audiences.** For each supporting objective, name the primary actors (the people who perform the behavior) and the secondary actors (the people who influence whether they do: approvers, leaders, key communicators, family, peers). Refine each to the most specific unit available. Organizations with a shared purpose and shared information sources are the strongest target. Demographic sets are the weakest, because members may share nothing but the label, and they are the default in most marketing only because media is easy to buy against them. Named leaders and key communicators (the people the audience already trusts for information) come next, and a message arriving through a key communicator is more credible than the same message from the business.

**3. Effectiveness, rated 0 to 5, per audience.** Three questions: what control does this audience have over the behavior, what restricts them (economic, legal, social, psychological, physical), and if every one of them acted, what share of the objective would that account for. A rating of 0, 1, or 2 means stop analyzing this audience. Either pick another or move the person who actually controls the decision into the plan as the real target.

**4. Current behavior.** Write down what the audience does today instead of the desired behavior, what causes it, and what it gives them. All behavior serves a purpose, and the current one is already being reinforced. Positive consequences nearly always fall into five buckets: escape or avoidance, access to something tangible, justice, power or control, and acceptance or affiliation. Immediate consequences outweigh distant ones. You beat a reinforced behavior by lowering the cost of switching first and raising the cost of staying second, in that order, and never with a feature list.

**5. Vulnerabilities.** The characteristics, motives, and conditions that can move the behavior. Motives first, primary (safety, security) before secondary (money, status, belonging, control). Then the nine psychographic questions, which produce sharper positioning inputs than any persona template: what does the audience fear, hate, get angry at, love, consider shameful, feel dissatisfied with, hold as a norm, value, and want that it cannot get. Then only the demographics that change the response to this behavior. Then symbols the audience already recognizes and trusts, because building recognition for a new symbol costs more than borrowing one.

**6. Susceptibility, rated 1 to 5, per audience.** How open the audience is to persuasion on this behavior: perceived risk, perceived reward, and consistency with their values. Immediate risks and rewards outweigh distant ones. This rating decides the shape of the campaign. Moderate to high susceptibility means a series built mostly on messages. Low susceptibility means a series built mostly on actions (a trial, a guarantee, a pricing change, a partnership, a product change), because conditions have to change before any message can land. State which it is before recommending a dollar of media spend. Spending media against a low-susceptibility audience is the most common and most expensive mistake in the field.

**7. Accessibility, per medium.** How the audience receives information today. Reach and frequency counted in people, never in subscribers or impressions. Whether the medium is used for entertainment or information, because an entertainment audience will not sit through a serious message. Whether it is consumed alone or in a group, because audiences that discuss a message with each other are more likely to be persuaded by it. Rate each medium 1 to 5 with its pros and cons.

**8. The argument.** Written before any headline, and containing no product wording. The main argument is one or two sentences in the form "doing X will result in Y," linking the desired behavior to the strongest vulnerability. Supporting arguments are facts, examples, and consequences from the current-behavior analysis, in sequence. One appeal, chosen from the allowed list in the house rules and drawn from `references/appeals-and-techniques.md`. One or two techniques. The argument is the foundation, and every product in the series is built on it.

**9. The series.** A campaign is a series, never a single product: every message and action built for one behavior and one audience, across a deliberate mix of media, so the audience meets the same argument several times in different forms. Assign each product to a supporting argument. Stage the supporting arguments, and write the gate into the calendar: stage two does not release until posttesting shows the audience accepted stage one. Actions are products. A free pilot, a training session, a guarantee, an audit, a public commitment, or a product change is planned on the same worksheet as the ad, and exists to make a supporting argument credible. Name every asset so it traces back to its objective, audience, and stage. Use `assets/series-worksheet.template.md`.

**10. Pretest plan.** Before anything ships, test for understanding and acceptance, never for liking. Ask what the piece tells the reader to do, what it says, and what it means to them. Ask about acceptance through peers, never the respondent ("after seeing this, would business owners like you do X, and why"), because asking about peers removes the pressure to be polite. Test three variants with different appeals. Report counts. Classify every deficiency as understanding, acceptance, or exposure. Fixes are one of four: change the product, change the argument, change the dissemination, or split the audience, which is the right answer whenever results diverge along a line you had not drawn. Use `assets/pretest-sheet.template.md`.

**11. Approval.** One named approver from the house rules. Simultaneous review by everyone who needs to see it, with a fixed hour after which silence is consent. Reviewers comment and do not veto. The series does not go back to the writers until the final decision. This is the fix for the review bottleneck every marketing team has.

**12. Assessment.** Criteria written as questions whose answers, collected over time, describe a behavior trend ("how many members of the audience did X in the period"). Baseline before launch. Indicators at fixed intervals before, during, and after. A spontaneous events log kept beside the metrics: the competitor launch, the price change, the news story, the outage, anything outside the campaign that moved the behavior. Without the log, every dip and spike gets credited to the campaign. Report exposure, understanding, and acceptance as counts from real conversations. Reallocate budget to the product that posttests best, even when it is the humblest one. Use `assets/evaluation-report.template.md`.

## Depth

The house rules set a depth. **Full** produces all twelve sections. **Short** produces five: the objective with its behaviors and baseline, the audiences with primary and secondary actors and a susceptibility rating, the current behavior and what it gives the audience, the main argument with one appeal, and a series of three products with one gate and one assessment question. Short mode is for a small business or a fast turnaround, and it still refuses attitude objectives and still rates susceptibility before recommending spend.

## Checklist mode

Run these against the plan and report only what fails, each with the fix.

1. Is the objective a countable behavior with a baseline, or an attitude?
2. Are primary and secondary actors named? Is the target an organization or a demographic set?
3. Has effectiveness been rated, and is anyone rated below 3 still in the plan?
4. Is the current behavior written down, with what it gives the audience?
5. Has susceptibility been rated, and does the split between messages and actions follow it?
6. Is there a main argument in "X will result in Y" form, written before the headline?
7. Is the appeal on the allowed list, and does it violate the floor?
8. Is the series staged with a gate, or does everything ship at once?
9. Is there a pretest with peer questions and counts?
10. Is there a named approver, a review hour, and a spontaneous events log?
11. Does any line make a claim the audience can refute?

## Writing the output

Declarative and direct. Complete sentences. Plain words over industry jargon, and the audience's own words over the business's words. State rules in the affirmative. Give the short version first and the reasoning when asked. When the user has shown their own version of something, match its length and plainness. Follow the punctuation and tone rules in the house rules.

## Files in this skill

- `references/method.md`: the full seven-phase method with rating scales, verb lists, the nine psychographic questions, series staging, product design rules, pretest and posttest procedure, approval structure, the face-to-face encounter outline, and the evaluation report format. Read it when a section of the brief needs more than this file gives.
- `references/appeals-and-techniques.md`: the six appeal families, the presentation techniques, the influence tactics, and which of them the floor removes.
- `references/worked-example.md`: a complete brief for a fictional business, showing every section filled in.
- `assets/house-rules.template.md`: the configuration file the user fills in once.
- `assets/campaign-brief.template.md`, `assets/audience-worksheet.template.md`, `assets/series-worksheet.template.md`, `assets/pretest-sheet.template.md`, `assets/evaluation-report.template.md`: the worksheets.
