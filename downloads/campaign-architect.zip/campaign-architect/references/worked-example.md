# Worked Example: Ridgeline Roasters Wholesale Program

A complete brief in full depth for a fictional business. Every name, number, and source is invented for the example. Use it to see what each section looks like when it is done.

**Business.** Ridgeline Roasters, a specialty coffee roaster in a mid-sized metro area. Retail café and online bag sales are established. The company is launching a wholesale program supplying beans, barista training, and equipment service to independent cafés.

**House rules in force.** Tone: plain, warm, no exclamation points. Banned words: artisanal, curated, elevated, premium, seamless. Allowed appeals: legitimacy, bandwagon with real numbers, self-interest in gain framing. Approver: the owner. Review hour: 5 p.m. on the day of submission. Depth: full.

---

## 1. Objective

**Campaign objective.** Increase the number of independent cafés in the metro area buying beans from Ridgeline on a standing order.

**Supporting objective A.** The café owner places a first wholesale order of at least one case.
**Supporting objective B.** The café owner converts the first order to a standing weekly order within sixty days.
**Supporting objective C.** A café already on a standing order recommends Ridgeline to another café owner, in person or in the owners' group.

Each passes the three tests: orders and standing orders are counted in the order system, and a recommendation is counted when a new account names who sent them.

**Baseline.** Standing wholesale accounts today: four, all from personal relationships. First orders in the last six months: three. Referrals: zero recorded, because nobody was asked. The order system will add a "who sent you" field before launch (source: owner interview, assumption that the field can be added in a week).

## 2. Audiences

**For A and B, primary actors:** owners of independent cafés with one or two locations in the metro area. There are 61 of them (source: the metro café owners' Facebook group roster, cross-checked against the county business registry).

**Refined to organization type:** the Metro Independent Café Owners group (about 40 active members, meets monthly) and the four cafés that already buy from Ridgeline.

**Secondary actors:** the head barista at each café, who tastes and recommends, the café's current roaster's sales rep, who visits monthly, and the two owners who founded the owners' group and whose opinions carry the room (key communicators).

**For C, primary actors:** the four current standing-order owners. **Secondary actors:** their head baristas.

## 3. Effectiveness

**Café owners, for A and B: 4.** They control the buying decision outright. Restriction: economic, since switching means running down existing stock and risking a week of inconsistent drinks. Restriction: social, since the current roaster's rep is often a friend. If every owner in the group acted, that is two thirds of the objective.

**Head baristas: 2.** They influence the owner and do not sign. Recorded as secondary actors, not targets. Their effect is captured through the owner.

**Current standing-order owners, for C: 5.** They control whether they recommend, and one recommendation from a peer accounts for more first orders than any ad, based on the four existing accounts all having come through personal relationships (source: owner).

## 4. Current behavior

Café owners buy from one of two larger regional roasters on a standing order set up years ago. Causes: the rep visits monthly and handles problems in person, the account was set up by the previous owner or at opening when there was no time to compare, and the beans are consistent. Effects: the owner never thinks about coffee sourcing, which is the point.

What the current behavior gives them, by bucket: **escape or avoidance** of a decision that could produce a bad week of drinks, **power or control** through a rep who fixes problems, and **affiliation**, since most cafés in the group use the same two roasters and compare notes on them.

Negative consequences the owners name: price increases twice in the last year (source: owners' group thread, March), and no training for new baristas, so drink quality drops with every hire (source: three owner conversations, labeled as a small sample).

Lowering the cost of switching comes first: the risk of a bad week. Raising the cost of staying comes second: the untrained new hire.

## 5. Vulnerabilities

**Motives.** Secondary: money (margin on each cup), control (drink quality without the owner behind the bar), status among peer owners.

**Psychographics.** Fear: a bad review that names the coffee. Hate: being treated as a small account by a big roaster. Anger: price increases delivered by email. Love: a regular who orders the same drink every day. Shame: a new barista serving a bad cup in front of the owner. Dissatisfaction: no one trains their staff. Norm: you stay with your roaster unless something goes wrong. Value: independence, being the place that is not a chain. Frustration: they know their coffee could be better and cannot get the training to make it so.

**Demographics that matter:** number of locations (two-location owners are more price-sensitive and less present behind the bar). Nothing else changes the response.

**Symbols.** The owners' group logo, which appears on every member café's door. The "independent" identity. The Ridgeline retail café, which many owners have visited.

## 6. Susceptibility

**Café owners: 2, low.** Perceived risk is immediate and concrete (a bad week). Perceived reward is distant (better margin over a year). The norm is to stay put. This rating decides the campaign: it is built mostly on actions, with messages in support.

**Current standing-order owners, for C: 4.** They already switched and are consistent with their own choice. Messages will work here.

## 7. Accessibility

| Medium | Reach in people | Use | Alone or group | Rating |
|---|---|---|---|---|
| Owners' group monthly meeting | 25 to 35 per meeting | Information | Group | 5 |
| Owners' group Facebook thread | About 40 active | Information and gossip | Group | 4 |
| In-café visit by Ridgeline owner | One at a time, all 61 reachable in eight weeks | Information | Alone or with the barista | 5 |
| Local food newsletter | Unknown owner readership, labeled as an assumption | Entertainment | Alone | 2 |
| Instagram | Owners follow for aesthetics, not sourcing | Entertainment | Alone | 1 |

The group meeting and the in-person visit carry the campaign. Instagram is dropped for this objective.

## 8. The argument

**Main argument.** Switching to Ridgeline will give you consistent drinks from every barista you hire, without a bad week in between.

**Supporting arguments, in sequence.**
1. Your first two weeks run on free trial cases, in parallel with your current stock, so there is no week where the drinks change without you deciding they should. (Addresses the risk. Delivered by an action.)
2. Every new barista you hire gets a two-hour training at your bar within seven days of starting, at no charge, for as long as you buy from us. (Addresses the frustration. Delivered by an action.)
3. Three cafés in the owners' group are already on a standing order, and you can ask them. (Bandwagon with a real number. Delivered by message and by the owners themselves.)

**Appeal:** self-interest in gain framing, with legitimacy through the two key communicators once one of them is an account.

**Techniques:** specific instances (named cafés, with permission) and presenting the other side.

**The other side, published:** Ridgeline is smaller than your current roaster. If your roaster's rep fixes a grinder at 7 a.m. on a Saturday, we cannot promise that yet. What we promise is the training and the trial.

## 9. The series

**Stage one: the trial.** Products: an in-person visit to each of the 61 cafés over eight weeks (action), a one-page trial offer left behind (print), and a post in the owners' group thread from the Ridgeline owner announcing the trial in plain terms (message). Gate: stage two releases when posttesting shows at least six of ten visited owners can state the trial terms correctly and at least three have started one.

**Stage two: the training.** Products: the first training sessions at the trial cafés (action), a short account by one trial owner in the group meeting (face-to-face through a key communicator), and a second one-pager on the training promise (print). Gate: stage three releases when at least three trial cafés have converted to a standing order.

**Stage three: the peers.** Products: "ask them" cards naming the standing-order cafés, with permission (print), a five-minute slot at the monthly meeting for one owner to describe the switch (face-to-face), and the "who sent you" question on every first order (system).

**Asset names** follow the convention: RR-WHOLESALE-A-OWNERS-PRINT-S1-01, and so on.

## 10. Pretest plan

Before the first visit, show the one-page trial offer to five owners outside the metro area (a panel of representatives) and to the four current accounts. Ask: What does this tell you to do? What does it mean for you? Then: Would owners like you start a trial after reading this, and why or why not? Test three versions, one leading with the trial, one with the training, one with the peer cafés. Report counts. If the owners of two-location cafés read it differently from single-location owners, split the audience.

## 11. Approval

Approver: the owner. Reviewers: the head roaster and the retail manager, simultaneously, comments by 5 p.m. on the day of submission. Silence is consent.

## 12. Assessment

**Criteria.** How many independent cafés placed a first wholesale order in the period? How many converted to a standing order within sixty days? How many first orders named a referring café?

**Baseline.** Three first orders in six months, four standing accounts, zero recorded referrals.

**Indicators.** Weekly, from the order system, starting four weeks before the first visit.

**Spontaneous events log.** The two regional roasters' next price change, the summer slowdown, any café closures, the owners' group leadership change in the fall.

**Posttest.** After stage one, ten owner conversations: did they see the offer, what did it tell them to do, would owners like them do it. Counts, not percentages. Reallocate print and visit time to whichever product the conversations show was carried into the café and kept.

**Report.** Monthly, in the evaluation report format, bottom line first.
