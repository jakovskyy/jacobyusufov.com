# Appeals, Techniques, and Influence Tactics

The appeal is the tone the argument is presented in. The technique is the presentation method. The tactic is the lever underneath. Choose the appeal from the audience's conditions and vulnerabilities (Phase II, steps 3 and 4), never from taste, and check the choice against the floor in SKILL.md and the allowed list in the house rules.

## The six appeal families

| Appeal | Mechanism | Marketing use | Status under the floor |
|---|---|---|---|
| Legitimacy | Authority (law, regulation, a superior), reverence (a respected institution or person), tradition (what is done without question), loyalty (groups the audience belongs to) | Compliance framing, association or professional-body endorsement, "how the best in the field have always done it," team or trade loyalty. Strongest when it arrives through a key communicator. | Allowed |
| Inevitability | The outcome will occur whether or not the audience acts. Requires proof, so credibility is everything | "The market is moving to X." Only works with evidence the audience can check. | Allowed only with checkable proof, and never as fear |
| In-group / out-group | Divides the audience from another group. Fails when the out-group cannot be portrayed negatively | "Us against the incumbents," category positioning built on an enemy | Removed by the floor |
| Bandwagon | The need to belong or conform, peer pressure and companionship | Social proof, adoption counts, "the businesses in your area already on it" | Allowed with real and current numbers only |
| Nostalgia | Positive: bring back the good days. Negative: do not go back to the bad ones | "When you owned the customer relationship" / "before the middlemen" | Positive form allowed. Negative form is fear framing |
| Self-interest | Gain or loss framed against what the audience wants | The direct benefit case | Gain framing allowed. Loss framing is fear framing |

Loss framing tests well in the short term and erodes trust in the long term, which is why the floor removes it. A campaign built on what the audience will lose trains the audience to associate the business with threat.

## Techniques

Presentation methods. Use one or two per argument.

- **Testimonial.** A person the audience recognizes or resembles vouches for the behavior. Strongest through a key communicator.
- **Plain folks.** The message comes from someone like the audience, in their words.
- **Specific instances.** Named cases with details. Beats any generalization.
- **Illustrations and narratives.** A story in which the behavior is integral to the resolution. The audience retells stories and forgets facts.
- **Statistics.** Short and clearly relevant, or leave them out.
- **Explanations.** How the thing works, for audiences who need to understand before they act.
- **Compare and contrast.** Effective when the audience has a needs conflict to resolve (two things they want that pull in different directions).
- **Compare for similarities.** "This is like the thing you already trust."
- **Presenting the other side.** State the strongest case against the behavior, at full weight. For cynical audiences who distrust anything that is all one way. This technique is also a floor requirement: when the audience cannot verify your value claim, they can verify whether you said the inconvenient thing.
- **Least of evils.** The behavior is the smallest cost among real alternatives. Honest only when the alternatives are real.
- **Simplification.** Reduce a complex choice to its deciding factor. Honest only when the factor is the deciding one.
- **Transference.** Borrow the standing of a symbol the audience already respects. Check that you have the right to borrow it.

Removed by the floor: name-calling, insinuation, glittering generalities (words that sound like virtue and mean nothing).

## Influence tactics

The levers under the techniques.

Allowed: expertise (demonstrated, not claimed), reciprocity (give first, and the gift must be real), consistency (small commitment leading to larger), moral appeal (only where the audience holds the value already), positive self-feeling ("people like you do this"), esteem of others (the audience's own peers), social proof (with real numbers), scarcity (only when true).

Removed by the floor: fear, aversive stimulation, debt (calling in favors), negative self-feeling (shame as a lever), punishments, manufactured scarcity or urgency.

## Choosing the appeal

1. Read the five benefit buckets from the current-behavior analysis. The bucket the current behavior serves tells you what the audience is protecting.
2. Read the nine psychographic answers. Frustrations and shames point at the strongest vulnerability.
3. Pick the appeal that turns that vulnerability into a reason to perform the new behavior without attacking the audience's current choice. The audience who feels judged for what they do today will not switch.
4. Check it against the house rules' allowed list and the floor.
5. Write the main argument in "doing X will result in Y" form with that appeal's tone, then pretest three variants with different appeals before committing.
