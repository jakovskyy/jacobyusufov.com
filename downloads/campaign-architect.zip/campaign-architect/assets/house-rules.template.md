# House Rules

Fill this in once. The skill reads it before every campaign. Replace every bracketed line. Delete lines that do not apply.

## The business

- Name: [business name]
- What it sells, in one sentence a customer would use: [ ]
- Products or services the skill may plan campaigns for: [list, one per line]
- Markets or regions: [ ]

## Who buys and who influences

For each product, the people who perform the buying or signing behavior (primary actors) and the people who influence whether they do (secondary actors: approvers, leaders, peers, family, the trusted voices the audience already listens to).

- [Product]: primary actors [ ]. Secondary actors [ ]. Key communicators [ ]
- [Product]: primary actors [ ]. Secondary actors [ ]. Key communicators [ ]

## Channels in use today

- [channel]: reach in people [ ], used for information or entertainment [ ], consumed alone or in a group [ ]

## Words

- Banned words (the skill will not use these): [ ]
- Preferred words and the terms the audience uses: [ ]
- Words with a specific meaning in this business: [ ]

## Appeals

The skill chooses from this list only. The floor in SKILL.md removes in-group versus out-group, fear framing, and loss framing for everyone.

- Allowed: [legitimacy / bandwagon with real numbers / self-interest in gain framing / positive nostalgia / inevitability with checkable proof]

## Tone

- Formality: [conversational / formal / both, and when]
- Sentence rules: [complete sentences, punctuation rules, anything you always cut]
- Headline rule: [e.g. the benefit is in the headline, never implied]
- Numbers in copy: [e.g. never hardcode a count that the product computes, describe the method and the window instead]

## Claims

- Claims the business will never make: [ ]
- Claims that require proof on the page: [ ]
- Disclosures that always appear: [partnerships, sponsorships, affiliate relationships]

## Approval

- Named approver: [ ]
- Reviewers: [ ]
- Review hour after which silence is consent: [ ]

## Depth

- [full / short] (full is twelve sections, short is five)

## Baselines you already have

- [behavior]: [current count and period, and where it is measured]
