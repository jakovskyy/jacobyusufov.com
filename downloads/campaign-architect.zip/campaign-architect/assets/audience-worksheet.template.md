# Audience Worksheet: [audience] for supporting objective [A/B/C]

One worksheet per audience per supporting objective.

Supporting objective: The [audience] [verb] [object].

## Step 1. Identify and refine

Primary or secondary actor: [ ]
Audience type: [organization / defined group / leader / key communicator]
Refined to: [named organizations, named people, defined groups]
Size, with source: [ ]

## Step 2. Effectiveness (0 to 5)

Control over the behavior: [ ]
Restrictions (economic, legal, social, psychological, physical): [ ]
Share of the objective if all act: [ ]
Rating: [ ]. If 0 to 2, stop here and name the real target: [ ]

## Step 3. Conditions

Current behavior: [ ]
Causes, external: [ ]. Causes, internal: [ ]
Positive consequences by bucket: [ ]
Negative consequences the audience names: [ ]
Sources: [ ]. Assumptions, labeled: [ ]

## Step 4. Vulnerabilities

Motives, primary then secondary: [ ]
Fear / hate / anger / love / shame / dissatisfaction / norm / value / frustration: [ ]
Demographics that change the response: [ ]
Symbols: [ ]

## Step 5. Susceptibility (1 to 5)

Perceived risk: [ ]. Perceived reward: [ ]. Value consistency: [ ]
Rating: [ ]. Series built mostly on: [messages / actions]

## Step 6. Accessibility

| Medium | Reach in people | Frequency | Info or entertainment | Active or passive | Alone or group | Rating | Pros / cons |
|---|---|---|---|---|---|---|---|

## Step 7. Argument for this audience

Main argument: Doing [X] will result in [Y].
Supporting arguments: [ ]
Appeal: [ ]. Techniques: [ ]
Recommended actions (things to do in the world, not say): [ ]

## Step 8. Assessment criteria

Questions whose answers over time show the trend: [ ]
Measure the desired behavior (if increasing) or the current behavior (if decreasing): [ ]
