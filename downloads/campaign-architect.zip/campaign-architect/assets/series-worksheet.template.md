# Series Worksheet: [series name]

Supporting objective: [ ]. Audience: [ ].
Main argument: [ ]. Appeal: [ ]. Techniques: [ ]. Symbols repeated across every product: [ ].

## Staging

| Stage | Supporting argument carried | Products and actions | Gate to next stage (posttest condition) |
|---|---|---|---|
| 1 | | | |
| 2 | | | |
| 3 | | | |

## Dissemination plan

| Asset name | Medium | Stage | Duration | Timing | Frequency | Location / placement | Quantity |
|---|---|---|---|---|---|---|---|

Asset naming: [campaign]-[objective]-[audience]-[medium]-[stage]-[sequence]

## Actions as products

| Action | Supporting argument it makes credible | Owner | Date |
|---|---|---|---|

## Saturation check

Products per person per week, by medium: [ ]. Ceiling: [ ].
