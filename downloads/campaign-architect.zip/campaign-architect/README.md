# Campaign Architect

An agent skill that plans campaigns the way behavior-change professionals do. Objectives are countable behaviors. Every objective names who performs it and who influences them. Analysis starts with what the audience does today and why. A susceptibility score decides whether the campaign spends on messages or changes the offer. The series is staged with go/no-go gates, pretested before it ships, and measured against a baseline with a log of everything else that moved the number.

It works for any product, service, cause, or candidate. You configure it once with a house-rules file, and every campaign after that comes out in your words, inside your limits.

## What is inside

```
campaign-architect/
├── SKILL.md                              the instructions the agent follows
├── README.md                             this file
├── LICENSE.md
├── references/
│   ├── method.md                         the full seven-phase method
│   ├── appeals-and-techniques.md         appeals, techniques, tactics, and what the floor removes
│   └── worked-example.md                 a complete brief for a fictional business
└── assets/
    ├── house-rules.template.md           the configuration you fill in once
    ├── campaign-brief.template.md
    ├── audience-worksheet.template.md
    ├── series-worksheet.template.md
    ├── pretest-sheet.template.md
    └── evaluation-report.template.md
```

## Install

**Claude Code.** Copy the `campaign-architect` folder into `~/.claude/skills/` for all projects, or into `.claude/skills/` inside one project. Claude loads it when a campaign, launch, ad, or strategy comes up.

**Claude Cowork and claude.ai.** Upload the `.skill` file, or open `SKILL.md` and choose Save skill.

**Codex, OpenClaw, and other agents that read SKILL.md.** Place the folder where your agent looks for skills, or sync it through the MCP Market Hub.

## Quick start

1. Copy `assets/house-rules.template.md` to your project as `house-rules.md` and fill it in. Ten minutes. If you skip this, the skill runs a short intake the first time it fires and writes the file for you.
2. Ask for a campaign in your own words: "plan a push to get more of our trial users to upgrade," "we're launching X in March, build the campaign," "how do we get more owners to book a second appointment."
3. Read the brief. Section 1 tells you whether your objective can be counted. Section 6 tells you whether to spend on media at all.
4. To check something you already have, paste it and ask whether it holds up. The skill switches to checklist mode and reports only what fails.

## Two modes

**Brief mode** produces a twelve-section campaign brief in full depth, or a five-section brief in short depth. You choose the depth in the house rules.

**Checklist mode** runs eleven questions against an existing plan, ad, or deck and reports the failures with fixes.

## The floor

Six limits hold regardless of configuration: no deception, no false attribution, no fear or pressure tactics, no us-versus-them appeals, no claim the audience can refute, and the strongest case against the behavior published at the same weight as the case for it. A house-rules file can add limits. It cannot remove these. They are there because the method descends from influence doctrine, and the doctrine's own record shows that one false claim destroys credibility with every audience at once.

## Listing copy

**One line.** Plan campaigns as countable behaviors, with primary and secondary actors, current-behavior analysis, a susceptibility score that decides media versus offer, staged series with gates, pretests, and baseline-first evaluation.

**Key features.**
1. Objectives written as behaviors an observer can count, with a baseline before launch. Awareness and engagement are rejected at the planning stage.
2. Primary and secondary actors for every objective, refined to organizations and named trusted voices instead of demographic sets.
3. Current-behavior analysis: what the audience does today, what it gives them, and how to lower the cost of switching before raising the cost of staying.
4. A susceptibility score per audience that decides whether to spend on messages or change the offer, before a dollar of media is planned.
5. Staged series with go/no-go gates, actions planned as products, and asset names that trace back to the objective.
6. Pretest and posttest procedure with peer questions and counts, a spontaneous events log, and an evaluation report format.

**Use cases.**
- A founder planning a launch who needs a brief that survives contact with a finance team.
- A marketing team auditing a plan from an agency before signing off.
- A consultant who wants one method across clients in different industries, configured per client with a house-rules file.

## Version

1.0.0
